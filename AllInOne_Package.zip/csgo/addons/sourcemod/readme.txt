smlib 0.11 beta by Berni & Chanz

[Installation]
Simply extract the contents of this zip file into your sourcemod folder.
Then add #include <smlib> at the top of your sm plugin file and you are done.
Documentation of the Functions can be found below or inside the .inc files,
but we will also put online a dynamic Javascript API-Reference later.


Linux Compiler: It currently has a bug that hangs up the compiler when it tries to
open smlib.inc. As the Sourcemod Bug reporting is currently down,
download the fixed version from http://www.sourcemodplugins.org.