1. u need to install metamod+sourcemod first

files which u should edit:
csgo\mapcycle.txt (add maps)
csgo\gamemodes_server.txt (add maps)
csgo\addons\sourcemod\configs\mapchooser_extended\maps\csgo.txt (add maps)
csgo\cfg\sourcemod\kztimer\xxx.cfg (map type configs)
csgo\cfg\sourcemod\kztimer\kztimer.cfg (kztimer config)
csgo\cfg\gamemode_casual_server.cfg (server config)